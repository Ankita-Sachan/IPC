﻿namespace NamedPipeLibrary.Utilities
{
    public class TaskResult
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
    }
}
